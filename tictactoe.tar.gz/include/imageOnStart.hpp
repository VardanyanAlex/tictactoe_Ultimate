#ifndef IMAGEONSTART_HPP
#define IMAGEONSTART_HPP

/*
* Brief: Prints the Ultimate Tictactoe image when game lunchs 
*/
void startingImage();

#endif // IMAGEONSTART_HPP
