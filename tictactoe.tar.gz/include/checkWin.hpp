#ifndef CHECKWIN_HPP
#define CHECKWIN_HPP

/*
* Brief: Checks if any player won in any field or the whole game
*/
short int check(short **p);

#endif // CHECKWIN_HPP
