#ifndef YOUWIN_HPP
#define YOUWIN_HPP

/*
* Brief: prints you win message
*/
void youWin(short& whichPlayer);

#endif // YOUWIN_HPP
