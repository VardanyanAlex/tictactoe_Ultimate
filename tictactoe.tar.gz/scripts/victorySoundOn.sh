
#!bin/bash

#tput cup 200 150

mpg123 'soundEffect/victory.mp3' > /dev/null 2>&1


# endOfScript
