
#!bin/bash

pkill mpg123

# endOfScript