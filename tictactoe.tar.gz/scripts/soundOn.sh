
#!bin/bash

#tput cup 200 150

mpg123 --loop 100 -C 'soundEffect/play.mp3' > /dev/null 2>&1


# endOfScript
